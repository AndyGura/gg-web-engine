"""GG Web Engine scene export - the actual logic, kept free of any Blender-UI
concerns so it has exactly one home.

This module is imported two ways:
- by `operator.py`, as part of the registered add-on, for interactive export via
  `File > Export > GG Web Engine`;
- by `../scripts/export_cli.py`, standalone (no add-on install needed), for
  headless/CI batch export via `blender --background --python export_cli.py`.

Both entry points call the same functions below. If you need this export logic in
another project, install/vendor this add-on and import it - don't copy this file;
that's exactly the drift this module replaced (see blender-addon/README.md).

## Export formats

Right now there is exactly one export format: a `.glb` (geometry/materials/lights,
via Blender's own glTF exporter) plus a sidecar `.meta` JSON file carrying
everything glTF has no slot for - empties, curves/splines, and rigid body physics
shapes - consumed by `Gg3dLoader.loadGgGlb` (`packages/core/src/3d/loader.ts`) and
the `"Glb"` level-JSON class. `collect_scene_metadata()` below is deliberately kept
separate from the glTF-writing half of `export_glb_meta()`: a planned second export
format - serializing a scene directly to a GG level JSON document (see
`gg-engine-level-json`) instead of a GLB+meta sidecar - will reuse this same scene
walk and shape/curve/dummy parsing to build level-JSON entities rather than a
`.meta` sidecar, so avoid folding scene-walking logic into the glTF-specific half.
"""
import json
import os

import bpy
from rna_prop_ui import rna_idprop_value_to_python

# Bumped whenever the .meta JSON shape changes in a way old readers can't ignore.
# `Gg3dLoader`/`GgMeta` on the JS side can check this to warn on stale/future
# exports instead of silently misreading them.
#
# 2: `body.dynamic` (boolean) replaced by `body.bodyType` ('dynamic'|'static'|'kinematic_pos'|
#    'kinematic_vel') - see `get_rigid_body_description`'s own comment on how it's derived from
#    Blender's `type`/`kinematic` rigid body properties. `IPhysicsBody3dComponentLoader
#    .loadFromGgGlb` (`packages/core/src/3d/loaders.ts`) migrates an older `.meta`'s `dynamic`
#    field on the fly, so re-exporting isn't required, but a `.meta` written by this version can no
#    longer be read by a core build that only understands format 1.
GG_META_FORMAT_VERSION = 2


def parse_curve_obj(obj):
    curve = bpy.data.curves[obj.data.name]
    spline = curve.splines[0]
    is_cyclic = spline.use_cyclic_u
    points = [
        {
            "x": p.co.x + obj.location.x,
            "y": p.co.y + obj.location.y,
            "z": p.co.z + obj.location.z,
        }
        for p in spline.points
    ]
    return {
        "name": obj.name,
        "cyclic": is_cyclic,
        "points": points,
        **{x: rna_idprop_value_to_python(obj[x]) for x in obj.keys() if x != "_RNA_UI"},
    }


def parse_dummy_obj(obj):
    obj.rotation_mode = "QUATERNION"
    return {
        "name": obj.name,
        "position": {
            "x": obj.location.x,
            "y": obj.location.y,
            "z": obj.location.z,
        },
        "rotation": {
            "x": obj.rotation_quaternion.x,
            "y": obj.rotation_quaternion.y,
            "z": obj.rotation_quaternion.z,
            "w": obj.rotation_quaternion.w,
        },
        **{x: obj[x] for x in obj.keys() if x != "_RNA_UI"},
    }


def get_body_type(body):
    """Maps a Blender `RigidBodyObject`'s `type` ('ACTIVE'|'PASSIVE') + `kinematic` checkbox to
    this engine's `BodyType` ('dynamic'|'static'|'kinematic_pos'|'kinematic_vel' - see
    `packages/core/src/base/models/body-options.ts`).

    `kinematic` ("Animated" in the Physics panel) is only meaningful - and only exposed by
    Blender - on an `ACTIVE` body: checking it turns an otherwise-dynamic body into one driven
    entirely by its own keyframes/animation instead of forces, which is exactly `kinematic_pos`'s
    definition (a position-driven body Bullet still lets push/wake dynamic bodies it moves into).
    A `PASSIVE` body has no such checkbox - Blender lets you keyframe a Passive object's transform
    freely with no separate flag needed, since it was never being simulated in the first place -
    so there's no reliable, introspectable signal here to distinguish "genuinely static" from
    "Passive but animated" the way `kinematic` does for Active; every Passive body exports as
    plain `static` regardless.

    `kinematic_vel` (velocity-driven, as opposed to keyframe/position-driven) has no Blender
    authoring-time concept at all - it only makes sense for a body an app drives at runtime by
    setting `linearVelocity`/`angularVelocity` directly (e.g. a rotating platform) - so this
    exporter never produces it.
    """
    if body.type != "ACTIVE":
        return "static"
    if getattr(body, "kinematic", False):
        return "kinematic_pos"
    return "dynamic"


def get_rigid_body_description(obj, export_body_parameters=True):
    body = obj.rigid_body
    obj.rotation_mode = "QUATERNION"
    meta = {
        "name": obj.name,
        "position": {
            "x": obj.location.x,
            "y": obj.location.y,
            "z": obj.location.z,
        },
        # FIXME relative rotation
        "rotation": {
            "x": obj.rotation_quaternion.x,
            "y": obj.rotation_quaternion.y,
            "z": obj.rotation_quaternion.z,
            "w": obj.rotation_quaternion.w,
        },
        "shape": {
            "shape": body.collision_shape,
        },
    }
    if export_body_parameters:
        meta["body"] = {
            "bodyType": get_body_type(body),
            "mass": body.mass,
            "restitution": body.restitution,
            "friction": body.friction,
        }
    parent = obj.parent
    while parent:
        meta["position"]["x"] -= parent.location.x
        meta["position"]["y"] -= parent.location.y
        meta["position"]["z"] -= parent.location.z
        parent = parent.parent
    meta["position"]["x"] = round(meta["position"]["x"], 6)
    meta["position"]["y"] = round(meta["position"]["y"], 6)
    meta["position"]["z"] = round(meta["position"]["z"], 6)
    if meta["shape"]["shape"] == "SPHERE":
        meta["shape"]["radius"] = max(obj.dimensions.x, obj.dimensions.y, obj.dimensions.z) / 2
    elif meta["shape"]["shape"] == "BOX":
        meta["shape"]["dimensions"] = {"x": obj.dimensions.x, "y": obj.dimensions.y, "z": obj.dimensions.z}
    elif meta["shape"]["shape"] in ["CONE", "CYLINDER"]:
        meta["shape"]["radius"] = max(obj.dimensions.x, obj.dimensions.y) / 2
        meta["shape"]["height"] = obj.dimensions.z
    elif meta["shape"]["shape"] == "CAPSULE":
        meta["shape"]["radius"] = max(obj.dimensions.x, obj.dimensions.y) / 2
        meta["shape"]["centersDistance"] = obj.dimensions.z - max(obj.dimensions.x, obj.dimensions.y)
    elif meta["shape"]["shape"] == "CONVEX_HULL":
        meta["shape"]["vertices"] = [{"x": v.co.x, "y": v.co.y, "z": v.co.z} for v in obj.data.vertices]
    elif meta["shape"]["shape"] == "MESH":
        meta["shape"]["vertices"] = [{"x": v.co.x, "y": v.co.y, "z": v.co.z} for v in obj.data.vertices]
        import bmesh

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bmesh.ops.triangulate(bm, faces=bm.faces[:])
        meta["shape"]["faces"] = [[v.index for v in f.verts] for f in bm.faces]
        bm.free()
    elif meta["shape"]["shape"] == "COMPOUND":
        meta["shape"]["children"] = [
            get_rigid_body_description(sub_obj, export_body_parameters=False)
            for sub_obj in bpy.context.scene.objects
            if sub_obj.rigid_body is not None and sub_obj.parent == obj
        ]
    else:
        raise NotImplementedError(f"GG does not support exporting rigid body {meta['shape']['shape']} shape")
    return meta


def collect_scene_metadata():
    """Walk `bpy.context.scene.objects` and return the format-agnostic dict of
    curves/dummies/rigid bodies described in this module's docstring. Also drives
    which objects get selected for the glTF export in `export_glb_meta` below, so
    call this before touching `obj.select_set`.
    """
    metadata = {"formatVersion": GG_META_FORMAT_VERSION, "curves": [], "dummies": [], "rigidBodies": []}
    for obj in bpy.data.objects:
        if obj.type == "CURVE":
            metadata["curves"].append(parse_curve_obj(obj))
        elif obj.type == "EMPTY":
            metadata["dummies"].append(parse_dummy_obj(obj))
    for obj in bpy.context.scene.objects:
        if obj.rigid_body is None:
            continue
        parent_body = obj.parent.rigid_body if obj.parent else None
        if parent_body is not None and parent_body.collision_shape == "COMPOUND":
            continue  # exported as a child of the COMPOUND shape instead
        metadata["rigidBodies"].append(get_rigid_body_description(obj))
    return metadata


# `export_vertex_color` values accepted by `export_glb_meta` (Blender's glTF exporter's own
# `export_vertex_color` enum, Blender 4.2+).
VERTEX_COLOR_MODES = ("MATERIAL", "ACTIVE", "NONE")


def export_glb_meta(
    filepath,
    export_materials=True,
    copyright="",
    export_normals=True,
    export_tangents=True,
    export_texcoords=True,
    export_vertex_color="MATERIAL",
    export_lights=True,
):
    """Export whatever is currently loaded in `bpy.context` as a `.glb` + `.meta`
    pair at `filepath` (no extension - `.glb`/`.meta` are appended). Caller is
    responsible for opening the right `.blend` first (the interactive operator
    doesn't need to - it already has one open; the headless CLI does).

    The keyword options map onto Blender's glTF exporter (`bpy.ops.export_scene.gltf`)
    and only change the `.glb`; the `.meta` sidecar is the same either way. Their
    defaults are this exporter's long-standing output, which is not the same as the
    glTF exporter's own defaults (tangents are on here, off there):

    - `export_materials`: False writes no materials/textures at all (glTF
      `export_materials="NONE"`, which also merges each mesh's per-material
      primitives into one).
    - `copyright`: the glTF `asset.copyright` string.
    - `export_normals`: write the NORMAL attribute. With False, Blender's glTF
      exporter (checked against io_scene_gltf2 5.2) also skips TANGENT whatever
      `export_tangents` says, and no longer splits vertices by normal: a vertex is
      only duplicated where UVs, colors or materials differ, so hard-edged meshes
      get fewer vertices. The loader then gets no normals (three.js's GLTFLoader
      switches such a mesh's lit material to `flatShading`), so use it for meshes
      rendered unlit (e.g. `MeshBasicMaterial`).
    - `export_tangents`: write the TANGENT attribute (only needed by normal maps).
      Only takes effect with `export_normals` and `export_texcoords`, and on
      meshes that have a UV map: tangents follow the UVs, and without TEXCOORD_n
      in the file nothing can use them.
    - `export_texcoords`: write TEXCOORD_n (UV maps). False also turns tangents off.
    - `export_vertex_color`: which color attributes become COLOR_n. "MATERIAL" is
      the glTF exporter's default (the colors a material's node tree reads; with
      its other defaults also the active color of a mesh without material, and the
      remaining color attributes); "ACTIVE" forces the active color attribute;
      "NONE" writes no COLOR_n at all. Passed to the glTF exporter only when it
      isn't "MATERIAL", so the default call stays the same on every Blender version.
    - `export_lights`: write lights (KHR_lights_punctual). Light objects are still
      selected for export either way.
    """
    if export_vertex_color not in VERTEX_COLOR_MODES:
        raise ValueError(f"export_vertex_color must be one of {VERTEX_COLOR_MODES}, got {export_vertex_color!r}")
    out_dir = os.path.dirname(filepath)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    metadata = collect_scene_metadata()

    for obj in bpy.context.scene.objects:
        include_in_export = obj.type in ["MESH", "LIGHT", "CURVE"]
        include_in_glb = not obj.hide_render
        obj.select_set(state=include_in_export and include_in_glb)
        if not include_in_export:
            continue
        for modifier in obj.modifiers:
            bpy.ops.object.modifier_apply(modifier=modifier.name)

    optional_gltf_args = {}
    if export_vertex_color != "MATERIAL":
        optional_gltf_args["export_vertex_color"] = export_vertex_color
    bpy.ops.export_scene.gltf(
        export_format="GLB",
        export_copyright=copyright,
        export_texcoords=export_texcoords,
        export_normals=export_normals,
        export_tangents=export_tangents and export_texcoords,
        export_materials="EXPORT" if export_materials else "NONE",
        export_cameras=False,
        export_lights=export_lights,
        export_extras=True,
        export_yup=False,
        export_apply=False,
        export_animations=False,
        use_selection=True,
        export_skins=False,
        export_morph=False,
        filepath=filepath + ".glb",
        **optional_gltf_args,
    )
    with open(filepath + ".meta", "w") as outfile:
        json.dump(metadata, outfile)
